import './App.css';
import { Admin } from './components/admin';
import {BrowserRouter,Route,Routes,Link} from 'react-router-dom';
import {CarViewList} from './components/carviewlist';
import {CustomerList} from './components/customerlist';
import { SellerAdd } from './components/selleradd';
import { SellerViewList } from './components/sellerviewlist';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
      <nav className="btn btn-warning navbar navbar-expand-lg navheader">
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/admin" >Admin</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/selleradd" >Add Car </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/sellerviewlist" >Seller List </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/carviewlist" >Car List </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/customerlist" >Customer List </Link>
            </li>

            {/* <li className="nav-item">
              <Link  className="nav-link" to="/booklist">BookList</Link>
            </li> */}
          </ul>
        </div>
      </nav>
      
      <Routes>
        <Route exact path="/admin" element={<Admin/>}></Route>
        <Route exact path="/selleradd" element={<SellerAdd/>}></Route>
        <Route exact path="/sellerviewlist" element={<SellerViewList/>}></Route>
        <Route exact path="/carviewlist" element={<CarViewList/>}></Route>
        <Route exact path="/customerlist" element={<CustomerList/>}></Route>
        {/* <Route exact path="/addbook" element={<AddBook/>}></Route>
        <Route exact path="/viewbook/:id" element={<ViewBook />}></Route>
        <Route exact path="/editbook/:id" element={<EditBook />}></Route> */}
      </Routes>

      </BrowserRouter>

    </div>
  );
}

export default App;
