import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate,useParams } from "react-router-dom";

export function CarList(props){
    const [car,setCar]=useState({});
    const param=useParams();
    const navigate=useNavigate();
    const url = "http://localhost:8086/api/cars/b/"+param.id;
   
    const getData = () =>{
        const data = axios.get(url);
        data.then(resp => setCar(resp.data))
        .catch(error => console.log(error));
    }
    useEffect(() => {
        getData();
    },[])

    return(
        <div>
            <h1>View car Component</h1>
            <button className = "btn btn-secondary" onClick={()=>{navigate(-1)}}>Go Back</button>
            <ul className="list-group">
                <li className="list-group-item">Car Id: {car.carId}</li>
                <li className="list-group-item">Brand: {car.brand}</li>
                <li className="list-group-item">Model: {car.model}</li>
                <li className="list-group-item">Price: {car.price}</li>
                <li className="list-group-item">Years Of Use: {car.no_of_years}</li>
                <li className="list-group-item">color: {car.color}</li>
                <li className="list-group-item">Booked: {car.booked}</li>
            </ul>
        </div>
    );
}