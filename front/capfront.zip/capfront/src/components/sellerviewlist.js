import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate} from "react-router-dom";

export function SellerViewList(props){
    const [sellers,setSellers]= useState([]);
    const url= "http://localhost:8086/api/sellers";

    const navigate = useNavigate();
    const getData = () =>{
        const data = axios.get(url);
        data.then(resp => setSellers(resp.data))
        .catch(error => console.log(error));
    }

    const deleteBook=(carId)=>{
        axios.delete(url+carId)
        .then(resp=>{console.log(resp); getData()})
        .catch(error=>console.log(error));
    }
    useEffect(()=>{
        getData();
    }, [])

    const tabRow = sellers.map((seller,index)=>{
        return (
            <tr key={index}>
                <td>{seller.sellerName}</td>
                <td>{seller.sellerEmail}</td>
                <td>{seller.carId}</td>
                <td>{seller.brand}</td>
                <td>{seller.model}</td>
                <td>{seller.color}</td>
                <td>{seller.no_of_years}</td>
                <td>{seller.price}</td>
                <td>{seller.booked}</td>
                <td>
                    <button className="btn btn-danger" 
                    onClick={()=>deleteBook(seller.carId)}>Delete</button>&nbsp;
                    {/* <button className="btn btn-success"
                    onClick={() => navigate("/editbook/"+book.id)}>Edit</button> */}
                </td>
            </tr>
        )
    })
    return(
        <div>
            <h1>Car Component</h1>
            <table className="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Seller Id</th><th>Seller Name</th><th>Seller Email</th><th>Car Id</th><th>Brand</th><th>Model</th><th>Color</th><th>Years of Use</th><th>Price</th><th>Booked</th>
                    </tr>
                </thead>
                <tbody>
                    {tabRow}
                </tbody>
            </table>
        </div>
    )
}