
export function Admin() {
    return (
      <div className="container">
  {/* <BrowserRouter>
      <nav className="btn btn-warning navbar navbar-expand-lg navheader">
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/carlist" >Car List</Link>
            </li>
            <li className="nav-item">
              <Link  className="nav-link" to="/booklist">BookList</Link>
            </li>
          </ul>
        </div>
      </nav>
      
      <Routes>
        <Route exact path="/carlist" element={<ViewCarList/>}></Route>
        <Route exact path="/addbook" element={<AddBook/>}></Route>
        <Route exact path="/viewbook/:id" element={<ViewBook />}></Route>
        <Route exact path="/editbook/:id" element={<EditBook />}></Route>
      </Routes>

      </BrowserRouter> */}
      <h1>hi</h1>
       </div>
    );
  }
  