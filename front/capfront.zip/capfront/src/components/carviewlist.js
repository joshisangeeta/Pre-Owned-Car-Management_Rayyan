import axios from "axios";
import { useEffect, useState } from "react";
import { useNavigate} from "react-router-dom";

export function CarViewList(props){
    const [cars,setCars]= useState([]);
    const url= "http://localhost:8086/api/cars";

    const navigate = useNavigate();
    const getData = () =>{
        const data = axios.get(url);
        data.then(resp => setCars(resp.data))
        .catch(error => console.log(error));
    }

    const deleteBook=(carId)=>{
        axios.delete(url+carId)
        .then(resp=>{console.log(resp); getData()})
        .catch(error=>console.log(error));
    }
    useEffect(()=>{
        getData();
    }, [])

    const tabRow = cars.map((car,index)=>{
        return (
            <tr key={index}>
                <td>{car.carId}</td>
                <td>{car.brand}</td>
                <td>{car.model}</td>
                <td>{car.color}</td>
                <td>{car.no_of_years}</td>
                <td>{car.price}</td>
                <td>{car.booked}</td>
                <td>
                    <button className="btn btn-danger" 
                    onClick={()=>deleteBook(car.carId)}>Delete</button>&nbsp;
                    {/* <button className="btn btn-success"
                    onClick={() => navigate("/editbook/"+book.id)}>Edit</button> */}
                </td>
            </tr>
        )
    })
    return(
        <div>
            <h1>Car Component</h1>
            <table className="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Id</th><th>Brand</th><th>Model</th><th>Color</th><th>Years of Use</th><th>Price</th><th>Booked</th>
                    </tr>
                </thead>
                <tbody>
                    {tabRow}
                </tbody>
            </table>
        </div>
    )
}