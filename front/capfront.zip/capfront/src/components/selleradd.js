import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export function SellerAdd(){
    const navigate=useNavigate();
    const [seller,setSeller]=useState({sellerName:"",sellerEmail:"",brand:"",model:"",color:"",no_of_years:"",price:""})
    const url = "http://localhost:8086/api/sellers"
    
    const inputHandler=(e)=>{
        setSeller((seller)=>({
            ...seller,
            [e.target.id]:e.target.value
        }))
    }

    const submitHandler=(e)=>{
        e.preventDefault();
        const data=axios.post(url,seller);
        data.then(resp=>{
            // if(resp.status===201)
            navigate('/carviewlist')
        })
        .catch(error=>console.log(error));
    }

    return(
        <div>
            <h1>Add Car</h1>
            <div className="row">
                <div className="col-md-6 offset-3">
                    <form className="form" onSubmit={submitHandler}>
                        <label>Seller Name</label>
                        <input type = "text" id="sellerName" placeholder="Enter Seller Name"
                        value={seller.sellerName} className="form-control" onChange={inputHandler}/>
                        <label>Seller Email</label>
                        <input type = "text" id="sellerEmail" placeholder="Enter Seller Email"
                        value={seller.sellerEmail} className="form-control" onChange={inputHandler}/>
                        <label>Brand</label>
                        <input type = "text" id="brand" placeholder="Enter Brand"
                        value={seller.brand} className="form-control" onChange={inputHandler}/>
                        <label>Model</label>
                        <input type = "text" id="model" placeholder="Enter Model"
                        value={seller.model} className="form-control" onChange={inputHandler}/>
                        <label>Color</label>
                        <input type = "text" id="color" placeholder="Enter Color"
                        value={seller.color} className="form-control" onChange={inputHandler}/>
                        <label>No Of Years</label>
                        <input type = "number" id="no_of_years" placeholder="Enter Years of use"
                        value={seller.no_of_years} className="form-control" onChange={inputHandler}/>
                        <label>Price</label>
                        <input type = "number" id="price" placeholder="Enter Price"
                        value={seller.price} className="form-control" onChange={inputHandler}/>
                        <br/>
                        <button className="btn btn-primary" type="submit">Add Car</button>
                    </form>
                </div>
            </div>
   
        </div>
    )

}