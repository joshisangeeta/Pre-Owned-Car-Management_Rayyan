import axios from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

export function AddCars(){
    const navigate=useNavigate();
    const [car,setCar]=useState({carId:"",brand:"",model:"",color:"",no_of_years:"",price:""})
    const url = "http://localhost:8086/api/cars";
    
    const inputHandler=(e)=>{
        setCar((car)=>({
            ...car,
            [e.target.id]:e.target.value
        }))
    }

    const submitHandler=(e)=>{
        e.preventDefault();
        const data=axios.post(url,car);
        data.then(resp=>{
            // if(resp.status===201)
            navigate('/carviewlist')
        })
        .catch(error=>console.log(error));
    }

    return(
        <div>
            <h1>Add Cars</h1>
            <div className="row">
                <div className="col-md-6 offset-3">
                    <form className="form" onSubmit={submitHandler}>
                        <label>Id</label>
                        <input type = "number" id="carId" placeholder="Enter Id"
                        value={car.carId} className="form-control" onChange={inputHandler}/>
                        <label>Brand</label>
                        <input type = "text" id="brand" placeholder="Enter Brand"
                        value={car.brand} className="form-control" onChange={inputHandler}/>
                        <label>Model</label>
                        <input type = "text" id="model" placeholder="Enter Model"
                        value={car.model} className="form-control" onChange={inputHandler}/>
                        <label>Color</label>
                        <input type = "text" id="color" placeholder="Enter Color"
                        value={car.color} className="form-control" onChange={inputHandler}/>
                        <label>No Of Years</label>
                        <input type = "number" id="no_of_years" placeholder="Enter Years of use"
                        value={car.no_of_years} className="form-control" onChange={inputHandler}/>
                        <label>Price</label>
                        <input type = "number" id="price" placeholder="Enter Price"
                        value={car.price} className="form-control" onChange={inputHandler}/>
                        <br/>
                        <button className="btn btn-primary" type="submit">Add Car</button>
                    </form>
                </div>
            </div>
   
        </div>
    )

}